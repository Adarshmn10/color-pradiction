from flask import Flask, render_template, request, session, redirect, url_for
import random

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Needed for session management

# List of colors
COLORS = ['red', 'blue', 'green', 'yellow', 'white']

@app.route('/')
def home():
    # Choose a random color and store in session
    session['color'] = random.choice(COLORS)
    session['attempts'] = 0
    return render_template('index.html')

@app.route('/guess', methods=['POST'])
def guess():
    user_guess = request.form['color_guess'].strip().lower()
    actual_color = session.get('color')
    session['attempts'] += 1

    if not actual_color:
        return redirect(url_for('home'))

    if user_guess == actual_color:
        return render_template('result.html', success=True, color=actual_color, attempts=session['attempts'])
    else:
        message = f"Wrong guess! Try again."
        return render_template('index.html', message=message, attempts=session['attempts'])

@app.route('/restart')
def restart():
    session.clear()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
